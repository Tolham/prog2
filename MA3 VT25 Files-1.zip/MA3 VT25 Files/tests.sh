#!/bin/bash
clear
echo "*** Exercise 1 ***"
python3 test_MA3_1.py

echo "*** Exercise 2 ***"
python3 test_MA3_2.py

echo "*** Exercise 3 ***"
python3 test_MA3_3.py

echo "*** Exercise 4 ***"
python3 test_MA3_4.py

echo "Done"